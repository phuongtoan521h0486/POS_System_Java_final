package com.thd.pos_system_java_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PosSystemJavaFinalApplicationTests {

    @Test
    void contextLoads() {
    }

}
