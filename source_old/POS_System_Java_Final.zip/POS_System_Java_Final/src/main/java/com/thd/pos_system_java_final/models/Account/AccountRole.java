package com.thd.pos_system_java_final.models.Account;

public enum AccountRole {
    ADMIN,
    EMPLOYEE
}
